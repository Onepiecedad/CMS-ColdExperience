# Roles & Access Control

| Role | Access | Responsibilities |
|------|---------|------------------|
| **Joakim (Owner)** | Full GitHub + CMS admin | System setup, config updates, code review |
| **Gustav (Editor)** | CMS UI only | Edit Swedish texts and images |
| **Automation Bot (n8n)** | GitHub API write access | Auto-translation and commits |
